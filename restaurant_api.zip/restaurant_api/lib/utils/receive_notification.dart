class ReceiveNotification {
 final int? id;
 final String? title;
 final String? body;
 final String? payload;

 ReceiveNotification({
   this.id,
   this.title,
   this.body,
   this.payload
  });
}