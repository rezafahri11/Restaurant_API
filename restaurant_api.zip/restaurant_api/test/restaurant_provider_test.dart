import 'package:flutter_test/flutter_test.dart';
import 'package:restaurant_api/data/api/api_service.dart';

void main() {
  test('Should contain 20 restaurants when "getRestaurants()" function being called', () async {
    // arrange
    ApiService apiService = ApiService();
    // act
    var resto = await ApiService().getRestaurants();
    // assert
    var result = resto.count == 20;
    expect(result, true);
  });
}