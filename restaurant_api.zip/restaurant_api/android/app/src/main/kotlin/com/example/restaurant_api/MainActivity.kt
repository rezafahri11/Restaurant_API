package com.example.restaurant_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
